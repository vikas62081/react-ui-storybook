'use strict';

import React, { useMemo, useRef, useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
// import 'ag-grid-enterprise';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'ag-grid-community/styles/ag-theme-material.css';
import './index.css';
import { ColDef } from 'ag-grid-community';
import CheckboxesTags from './autocomplete';
import FadeMenu from './autocomplete';

export const Grid = () => {
  const gridRef = useRef<any>(null);
  const [gridApi, setGridApi] = useState<any>(null);
  const gridStyle = useMemo(() => ({ height: 400, width: '100%' }), []);

  const defaultColDef = useMemo<ColDef>(() => {
    return {
      flex: 1,
      minWidth: 160,
      filter: true,
      resizable: true,
      suppressMenu: true,
    };
  }, []);

  const [rowData] = useState([
    { make: 'Toyota', model: 'Celica', price: 35000 },
    { make: 'Ford', model: 'Mondeo', price: 32000 },
    { make: 'Porsche', model: 'Boxster', price: 72000 },
    { make: 'Toyota', model: 'Audi', price: 350000 },
  ]);

  const [columnDefs] = useState([
    { field: 'make' },
    { field: 'model' },
    { field: 'price' },
  ]);
  const onGridReady = (params: any) => {
    console.log(params);
    setGridApi(params);
  };
  const onFilter = (a: any, b: any, c: any) => {
    var countryFilterComponent = gridApi.api.getFilterInstance(a);
    countryFilterComponent.setModel({
      type: b,
      filter: c,
    });
    gridApi!.api.onFilterChanged();
  };

  const a = [
    {
      id: 1,
      field: 'make',
      type: 'contains',
      onChange: (a: any, b: any, c: any) => onFilter(a, b, c),
    },
    {
      id: 2,
      field: 'model',
      type: 'contains',
      onChange: (a: any, b: any, c: any) => onFilter(a, b, c),
    },
    {
      id: 3,
      field: 'price',
      type: 'equals',
      onChange: (a: any, b: any, c: any) => onFilter(a, b, c),
    },
  ];

  return (
    <div>
      {a.map((dt) => (
        <>
          <label>{dt?.field}</label>
          <input
            onChange={(e) => dt.onChange(dt.field, dt.type, e?.target?.value)}
          />
        </>
      ))}
      <FadeMenu />
      <select onChange={(e) => onFilter('make', 'contains', e?.target?.value)}>
        <option value={''}>Select</option>
        <option value="Toyota">Toyota</option>
        <option value="Ford">Ford</option>
      </select>
      <div style={gridStyle} className="ag-theme-material">
        <AgGridReact
          ref={gridRef}
          rowData={rowData}
          columnDefs={columnDefs}
          defaultColDef={defaultColDef}
          sideBar={'filters'}
          onGridReady={onGridReady}
          // onFirstDataRendered={onFirstDataRendered}
        ></AgGridReact>
      </div>
    </div>
  );
};
